from flask import Blueprint, jsonify, request,send_file,redirect, url_for,render_template
from flask_login import current_user, login_required 
from datetime import datetime, timedelta
from app.models import User, Book, BookLoan
import uuid
from app import db
from flask import send_from_directory, current_app
from flask_login import current_user, login_required 
from datetime import datetime, timedelta
from app.models import User, Book, BookLoan
import uuid
from app import db
import os
import logging
import requests
from io import BytesIO




api = Blueprint('api', __name__)


@api.route('/api/books/<int:book_id>', methods=['GET'])
def get_book(book_id):
    book = next((book for book in BOOKS if book['id'] == book_id), None)
    if book is None:
        return jsonify({'error': 'Book not found'}), 404
    
    pdf_filename = f"{book['id']}.pdf"
    pdf_path = os.path.join(current_app.root_path, 'pdfs', pdf_filename)
    
    return jsonify({
        'id': book['id'],
        'title': book['title'],
        'author': book['author'],
        'isbn': book['isbn'],
        'quantity': book['quantity'],
        'price': book['price'],
        'image_url': book['image_url'],
        'available': book['quantity'] > 0,
        'description': book['description'],
        'pdf_available': os.path.exists(pdf_path)
    })
# Initialize with 18 books based on the author data
BOOKS = [{
    'id': 1,
    'title': "The Shining",
    'author': "Stephen King",
    'isbn': "978-0307743657", 
    'quantity': 8,
    'price': 19.99, 
    'link':"https://englishprofi.com.ua/wp-content/uploads/Stephen-King-The-Shining.pdf",
    'image_url': "https://images1.the-dots.com/v1/952815.jpg?p=projectImageFullJpg",
    'available': 5 > 0,
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre.",
    
},
    {
        'id': 2,
        'title': 'It Ends with Us',
        'author': 'Colleen Hoover',
        'isbn': '978-1501110368',
        'quantity': 8,
        'link':"https://icrrd.com/public/media/15-05-2021-052358It-Ends-with-Us.pdf",
        'price': 16.99,
        'borrowed_by': [],
        'image_url': 'https://d28hgpri8am2if.cloudfront.net/book_images/onix/cvr9781398520783/it-ends-with-us-9781398520783_hr.jpg',
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre."
        
    },
    {
        'id': 3,
        'title': 'The Lightning Thief',
        'author': 'Rick Riordan',
        'isbn': '978-0786838653',
        'quantity': 6,
        'link':"https://www.sausd.us/cms/lib/CA01000471/Centricity/Domain/241/lightning_thief_the__percy_jac_-_rick_riordan.pdf",
        'price': 14.99,
        'borrowed_by': [],
        'image_url': 'https://th.bing.com/th/id/OIP.mXv_zDux4gSpSU0InhLFFAHaLH?rs=1&pid=ImgDetMain',
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre."
        
    },
    {
        'id': 4,
        'title': 'A Court of Thorns and Roses',
        'author': 'Sarah J. Maas',
        'isbn': '978-1619634442',
        'quantity': 4,
        'link':"https://www.sausd.us/cms/lib/CA01000471/Centricity/Domain/241/1667793019_a-court-of-thorns-and-roses.pdf",
        'price': 17.99,
        'borrowed_by': [],
        'image_url': 'https://i5.walmartimages.com/asr/e1d13ac0-c959-43c3-bbf7-66b3c6541458.6652eee902b0f67ef62bbfe55850feb6.jpeg',
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre."
        
    },
    {
        'id': 5,
        'title': 'City of Bones',
        'author': 'Cassandra Clare',
        'isbn': '978-1416955078',
        'quantity': 7,
        'link':"https://www.sausd.us/cms/lib/CA01000471/Centricity/Domain/241/Cassandra%20Clare-City%20of%20Bones.pdf",
        'price': 15.99,
        'borrowed_by': [],
        'image_url': 'https://th.bing.com/th/id/OIP.WMD0zMyzRUA8pV1Ti41fXAHaLL?rs=1&pid=ImgDetMain',
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre."
        
    },
    {
        'id': 6,
        'title': 'Along Came a Spider',
        'author': 'James Patterson',
        'isbn': '978-0446364195',
        'quantity': 3,
        'price': 12.99,
        'link':"https://readerslibrary.org/wp-content/uploads/Along-came-a-Spider.pdf",
        'borrowed_by': [],
        'image_url': 'https://th.bing.com/th/id/R.342914406d444dca0e0d9ff5929eb3ee?rik=rPVPq8gKqi7vLQ&riu=http%3a%2f%2fwww.impawards.com%2f2001%2fposters%2falong_came_a_spider.jpg&ehk=h%2bTafw5rOfXuV222bygc2w1N%2fLw%2fLUFHPyOC7niIpOs%3d&risl=&pid=ImgRaw&r=0',
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre."
        
    },
    {
        'id': 7,
        'title': 'The Fault in Our Stars',
        'author': 'John Green',
        'isbn': '978-0525478812',
        'quantity': 9,
        'price': 13.99,
        'link':"https://www.juhsd.net/site/handlers/filedownload.ashx?moduleinstanceid=4480&dataid=7745&FileName=The-Fault-in-Our-Stars.pdf",
        'borrowed_by': [],
        'image_url': 'https://www.spreadingbook.com/wp-content/uploads/2020/08/The-Fault-in-Our-Stars-696x1024.jpg',
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre."
        
    },
    {
        'id': 8,
        'title': 'American Gods',
        'author': 'Neil Gaiman',
        'isbn': '978-0380789030',
        'quantity': 4,
        'link':"http://thecockinnbarbados.com/books/Neil_Gaiman_-_American_Gods.pdf",
        'price': 18.99,
        'borrowed_by': [],
        'image_url': 'https://www.femalefirst.co.uk/image-library/port/1000/a/american-gods-character-art-mr-wednesday-amazon.jpg',
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre."
        
    },
    {
        'id': 9,
        'title': 'Angels & Demons',
        'author': 'Dan Brown',
        'isbn': '978-1416524793',
        'quantity': 6,
        'link':"https://drive.google.com/file/d/0B-NeKKb4bOhKV0xfdWI4Tm9jNXM/view?resourcekey=0-eTeKV7SsS51j6mppG0Y4Ng",
        'price': 16.99,
        'borrowed_by': [],
        'image_url': 'https://d28hgpri8am2if.cloudfront.net/book_images/cvr9780743277716_9780743277716_hr.jpg',
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre."
        
    },
    {
        'id': 10,
        'title': 'The Notebook',
        'author': 'Nicholas Sparks',
        'isbn': '978-0446676090',
        'quantity': 5,
        'link':"https://drive.google.com/file/d/0B2ADaHV810PwSERVQVJtdFU1c1U/edit?resourcekey=0-H2aHQKhL7MCNX3Dd17-vKg",
        'price': 14.99,
        'borrowed_by': [],
        'image_url': 'https://www.hachettebookgroup.com/wp-content/uploads/2017/06/9780446676090.jpg',
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre."
        
    },
    {
        'id': 11,
        'title': 'Divergent',
        'author': 'Veronica Roth',
        'isbn': '978-0062024022',
        'quantity': 7,
        'link':"https://www.sausd.us/cms/lib/CA01000471/Centricity/Domain/241/Divergent.pdf",
        'price': 15.99,
        'borrowed_by': [],
        'image_url': 'https://www.bibdsl.co.uk/imagegallery2/bds/201408/9780007538065.JPG',
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre."
        
    },
    {
        'id': 12,
        'title': 'The Seven Husbands of Evelyn Hugo',
        'author': 'Taylor Jenkins Reid',
        'isbn': '978-1501161933',
        'quantity': 4,
        'link':"https://s1.papyruspub.com/files/demos/products/ebooks/novels/romance/Preview-The-Seven-Husbands-of-Evelyn-Hugo.pdf",
        'price': 19.99,
        'borrowed_by': [],
        'image_url': 'https://th.bing.com/th/id/OIP.NHqjry_d6Y2wkMQEqvwbawAAAA?rs=1&pid=ImgDetMain',
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre."
        
    },
    {
        'id': 13,
        'title': 'The Final Empire',
        'author': 'Brandon Sanderson',
        'isbn': '978-0765350381',
        'quantity': 3,
        'link':"",
        'price': 17.99,
        'borrowed_by': [],
        'image_url': 'https://th.bing.com/th/id/OIP.5sWDzZ5LTgEN4z0Z6zdVFQHaKl?rs=1&pid=ImgDetMain',
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre."
        
    },
    {
        'id': 14,
        'title': 'Six of Crows',
        'author': 'Leigh Bardugo',
        'isbn': '978-1627792127',
        'quantity': 6,
        'link':"",
        'price': 18.99,
        'borrowed_by': [],
        'image_url': 'https://th.bing.com/th/id/OIP.XbYNrYrOTumpazrHREx6MAHaLX?rs=1&pid=ImgDetMain',
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre."
        
    },
    {
        'id': 15,
        'title': 'A Time to Kill',
        'author': 'John Grisham',
        'isbn': '978-0440245919',
        'quantity': 5,
        'link':"",
        'price': 15.99,
        'borrowed_by': [],
        'image_url': 'https://flxt.tmsimg.com/assets/p18232_p_v10_aa.jpg',
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre."
        
    },
    {
        'id': 16,
        'title': 'Vision in White',
        'author': 'Nora Roberts',
        'isbn': '978-0425227510',
        'quantity': 4,
        'link':"",
        'price': 13.99,
        'borrowed_by': [],
        'image_url': 'https://th.bing.com/th/id/OIP.qAChLz_zwg7msW_0NUdCSwHaLr?rs=1&pid=ImgDetMain',
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre."
        
    },
    {
        'id': 17,
        'title': 'Gone Girl',
        'author': 'Gillian Flynn',
        'isbn': '978-0307588371',
        'quantity': 8,
        'link':"",
        'price': 16.99,
        'borrowed_by': [],
        'image_url': 'https://images.thenile.io/r1000/9781780228228.jpg',
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre."
        
    },
    {
        'id': 18,
        'title': 'My Sister\'s Keeper',
        'author': 'Jodi Picoult',
        'isbn': '978-0743454537',
        'quantity': 5,
        'link':"",
        'price': 14.99,
        'borrowed_by': [],
        'image_url': 'https://th.bing.com/th/id/OIP.ot_Ni0gUCCWyu_eMAn1nIAHaLd?rs=1&pid=ImgDetMain',
    'description': "The Shining is a horror novel by American author Stephen King. Published in 1977, it is King's third published novel and first hardback bestseller. The success of the book firmly established King as a preeminent author in the horror genre."
        
    }
]
def find_book(book_id):
    return next((book for book in BOOKS if book['id'] == book_id), None)


@api.route('/api/books', methods=['GET'])
def get_books():
    """
    Fetches a list of books with optional search and pagination.
    """
    search = request.args.get('search', '').lower()
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 12))

    filtered_books = [
        book for book in BOOKS if (
            search in book['title'].lower() or
            search in book['author'].lower() or
            search in book['isbn'].lower()
        )
    ] if search else BOOKS

    start_idx = (page - 1) * per_page
    paginated_books = filtered_books[start_idx:start_idx + per_page]

    return jsonify({
        'books': paginated_books,
        'total': len(filtered_books),
        'page': page,
        'per_page': per_page,
        'total_pages': (len(filtered_books) + per_page - 1) // per_page
    })




from flask import current_app, send_from_directory, render_template, flash, abort
from werkzeug.exceptions import NotFound, InternalServerError
import os

from flask import current_app, send_from_directory, render_template, flash, abort
import os


@login_required
@api.route('/download_book/<int:book_id>', methods=['GET'])
def download_book(book_id):
    # Find the book by its ID
    book = next((book for book in BOOKS if book['id'] == book_id), None)
    
    if book is None:
        return "Book not found", 404

    # Fetch the PDF from the external URL
    response = requests.get(book['link'])
    
    if response.status_code == 200:
        # Create an in-memory file to send back
        file = BytesIO(response.content)
        file.name = f"{book['title']}.pdf"  # Set the filename for the download
        return send_file(file, as_attachment=True, download_name=file.name, mimetype='application/pdf')
    else:
        return "Failed to download the book", 500
    

@api.route('/api/books/statistics', methods=['GET'])
@login_required
def get_statistics():
    """
    Returns book statistics specific to the logged-in user.
    """
    total_books = Book.query.count()
    available_books = Book.query.filter(Book.quantity > 0).count()
    user_borrowed = BookLoan.query.filter_by(user_id=current_user.id, returned=False).count()

    due_date_threshold = datetime.utcnow() + timedelta(days=3)
    due_soon = BookLoan.query.filter(
        BookLoan.user_id == current_user.id,
        BookLoan.return_date <= due_date_threshold,
        BookLoan.returned == False
    ).count()

    return jsonify({
        'total_books': total_books,
        'available_books': available_books,
        'user_borrowed': user_borrowed,
        'due_soon': due_soon
    })



@api.route('/api/books/<int:book_id>/borrow', methods=['POST'])
@login_required
def borrow_book(book_id):
    book = Book.query.get(book_id)
    if not book:
        return jsonify({'error': 'Book not found'}), 404

    if book.quantity <= 0:
        return jsonify({'error': 'Book is out of stock'}), 400

    data = request.get_json()
    try:
        issue_date = datetime.strptime(data.get('issue_date'), '%Y-%m-%d')
        return_date = datetime.strptime(data.get('return_date'), '%Y-%m-%d')
    except (ValueError, TypeError):
        return jsonify({'error': 'Invalid or missing date format'}), 400

    loan = BookLoan(
        book_id=book.id,
        user_id=current_user.id,
        issue_date=issue_date,
        return_date=return_date,
        receipt_number=f"LOAN-{uuid.uuid4().hex[:8].upper()}"
    )

    db.session.add(loan)
    book.quantity -= 1  # Decrement book quantity
    db.session.commit()  # Commit after both loan creation and book update

    return jsonify({
        'message': 'Book borrowed successfully',
        'loan_id': loan.id,
        'receipt_number': loan.receipt_number,
    })



@api.route('/api/book_image/<int:book_id>', methods=['GET'])
def get_book_image(book_id):
    # Define the folder where the book images are stored
    image_folder = os.path.join(current_app.root_path, 'static', 'book_images')

    # Check if the image exists
    image_filename = f"{book_id}.jpg"
    image_path = os.path.join(image_folder, image_filename)
    
    if not os.path.exists(image_path):
        return jsonify({'error': 'Image not found'}), 404
    
    return send_from_directory(image_folder, image_filename)



