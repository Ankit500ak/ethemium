# app/__init__.py
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from config import Config
import os



# BOOKS = [
#     {
#         'id': 1,
#         'title': 'The Shining',
#         'author': 'Stephen King',
#         'isbn': '978-0307743657',
#         'quantity': 5,
#         'price': 19.99,
#         'borrowed_by': [],
#         'image_url': '/static/images/it_ends_with_us.jpg'
#     },
#     {
#         'id': 2,
#         'title': 'It Ends with Us',
#         'author': 'Colleen Hoover',
#         'isbn': '978-1501110368',
#         'quantity': 8,
#         'price': 16.99,
#         'borrowed_by': [],
#         'image_url': '/static/images/it_ends_with_us.jpg'
#     },
#     {
#         'id': 3,
#         'title': 'The Lightning Thief',
#         'author': 'Rick Riordan',
#         'isbn': '978-0786838653',
#         'quantity': 6,
#         'price': 14.99,
#         'borrowed_by': [],
#         'image_url': '/static/images/it_ends_with_us.jpg'
#     },
#     {
#         'id': 4,
#         'title': 'A Court of Thorns and Roses',
#         'author': 'Sarah J. Maas',
#         'isbn': '978-1619634442',
#         'quantity': 4,
#         'price': 17.99,
#         'borrowed_by': [],
#         'image_url': '/static/images/it_ends_with_us.jpg'
#     },
#     {
#         'id': 5,
#         'title': 'City of Bones',
#         'author': 'Cassandra Clare',
#         'isbn': '978-1416955078',
#         'quantity': 7,
#         'price': 15.99,
#         'borrowed_by': []
#     },
#     {
#         'id': 6,
#         'title': 'Along Came a Spider',
#         'author': 'James Patterson',
#         'isbn': '978-0446364195',
#         'quantity': 3,
#         'price': 12.99,
#         'borrowed_by': []
#     },
#     {
#         'id': 7,
#         'title': 'The Fault in Our Stars',
#         'author': 'John Green',
#         'isbn': '978-0525478812',
#         'quantity': 9,
#         'price': 13.99,
#         'borrowed_by': []
#     },
#     {
#         'id': 8,
#         'title': 'American Gods',
#         'author': 'Neil Gaiman',
#         'isbn': '978-0380789030',
#         'quantity': 4,
#         'price': 18.99,
#         'borrowed_by': []
#     },
#     {
#         'id': 9,
#         'title': 'Angels & Demons',
#         'author': 'Dan Brown',
#         'isbn': '978-1416524793',
#         'quantity': 6,
#         'price': 16.99,
#         'borrowed_by': []
#     },
#     {
#         'id': 10,
#         'title': 'The Notebook',
#         'author': 'Nicholas Sparks',
#         'isbn': '978-0446676090',
#         'quantity': 5,
#         'price': 14.99,
#         'borrowed_by': []
#     },
#     {
#         'id': 11,
#         'title': 'Divergent',
#         'author': 'Veronica Roth',
#         'isbn': '978-0062024022',
#         'quantity': 7,
#         'price': 15.99,
#         'borrowed_by': []
#     },
#     {
#         'id': 12,
#         'title': 'The Seven Husbands of Evelyn Hugo',
#         'author': 'Taylor Jenkins Reid',
#         'isbn': '978-1501161933',
#         'quantity': 4,
#         'price': 19.99,
#         'borrowed_by': []
#     },
#     {
#         'id': 13,
#         'title': 'The Final Empire',
#         'author': 'Brandon Sanderson',
#         'isbn': '978-0765350381',
#         'quantity': 3,
#         'price': 17.99,
#         'borrowed_by': []
#     },
#     {
#         'id': 14,
#         'title': 'Six of Crows',
#         'author': 'Leigh Bardugo',
#         'isbn': '978-1627792127',
#         'quantity': 6,
#         'price': 18.99,
#         'borrowed_by': []
#     },
#     {
#         'id': 15,
#         'title': 'A Time to Kill',
#         'author': 'John Grisham',
#         'isbn': '978-0440245919',
#         'quantity': 5,
#         'price': 15.99,
#         'borrowed_by': []
#     },
#     {
#         'id': 16,
#         'title': 'Vision in White',
#         'author': 'Nora Roberts',
#         'isbn': '978-0425227510',
#         'quantity': 4,
#         'price': 13.99,
#         'borrowed_by': []
#     },
#     {
#         'id': 17,
#         'title': 'Gone Girl',
#         'author': 'Gillian Flynn',
#         'isbn': '978-0307588371',
#         'quantity': 8,
#         'price': 16.99,
#         'borrowed_by': []
#     },
#     {
#         'id': 18,
#         'title': 'My Sister\'s Keeper',
#         'author': 'Jodi Picoult',
#         'isbn': '978-0743454537',
#         'quantity': 5,
#         'price': 14.99,
#         'borrowed_by': []
#     }
# ]

db = SQLAlchemy()
login_manager = LoginManager()

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)
    
    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)
    
    app.config['UPLOAD_FOLDER'] = os.path.join(app.instance_path, 'uploads')

    # Ensure the upload folder exists
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])

    # Import routes or blueprints
    from .routes import main, auth
    
    # Configure login manager
    login_manager.login_view = 'auth.login'
    login_manager.login_message_category = 'info'
    
    # Register blueprints
    from app.routes import main, auth
    from app.api import api
    
    app.register_blueprint(main)
    app.register_blueprint(auth, url_prefix='/auth')
    app.register_blueprint(api)  # Register the API blueprint

    # Create database tables
    with app.app_context():
        # db.drop_all()
        db.create_all()
        # Create admin user if it doesn't exist
        from app.models import User,Book
        if not User.query.filter_by(username='admin').first():
            admin = User(
                username='admin',
                email='admin@example.com',
                is_admin=True
            )
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()

        # for book_data in BOOKS:
        #     book = Book(
        #         id=book_data['id'],
        #         title=book_data['title'],
        #         author=book_data['author'],
        #         isbn=book_data['isbn'],
        #         quantity=book_data['quantity'],
        #         price=book_data['price'],
        #         # borrowed_by=[],
        #         # image_url=book_data.get('image_url')
        #     )
        #     db.session.add(book)
        #     db.session.commit()
        #     print("Books data inserted successfully!")    
    

    
    return app