from datetime import datetime, timedelta
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db, login_manager



@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))
    is_admin = db.Column(db.Boolean, default=False)
    loans = db.relationship('BookLoan', backref='user', lazy='dynamic')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f'<User {self.username}>'

class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    author = db.Column(db.String(100), nullable=False)
    isbn = db.Column(db.String(13), unique=True)
    quantity = db.Column(db.Integer, default=1)
    price = db.Column(db.Float, nullable=False)
    borrowed_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    loans = db.relationship('BookLoan', backref='book', lazy='dynamic')
    
    def borrow(self, user):
        if self.quantity > 0:
            loan = BookLoan(user=user, book=self, return_date=datetime.utcnow() + timedelta(days=14))
            self.quantity -= 1
            db.session.add(loan)
            db.session.commit()
            return loan
        else:
            return None

    def __repr__(self):
        return f'<Book {self.title}>'
    
    

class BookLoan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False)
    issue_date = db.Column(db.DateTime, default=datetime.utcnow)
    return_date = db.Column(db.DateTime, nullable=False)
    returned = db.Column(db.Boolean, default=False)
    receipt_number = db.Column(db.String(20), unique=True)
    
    # book = db.relationship('Book', backref='loans')  # Relationship to Book
    


    def __repr__(self):
        return f'<BookLoan {self.receipt_number}>'