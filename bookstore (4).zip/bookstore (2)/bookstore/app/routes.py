from flask import (
    Blueprint,
    render_template,
    redirect,
    url_for,
    flash,
    request,
    abort,
    jsonify,
    send_file,
    current_app,
    send_from_directory,
)
from werkzeug.utils import secure_filename
import logging
from flask_login import login_user, logout_user, login_required, current_user
from datetime import datetime, timedelta
from app.models import User, Book, BookLoan
from PyPDF2 import PdfReader
from app import db
import uuid
import os

main = Blueprint('main', __name__)
auth = Blueprint('auth', __name__)

# Authentication Routes
@auth.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'error')
            return redirect(url_for('auth.register'))
            
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'error')
            return redirect(url_for('auth.register'))
            
        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful!', 'success')
        return redirect(url_for('auth.login'))
    
    return render_template('register.html')


@auth.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = request.form.get('remember', False) == 'on'
        
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user, remember=remember)
            next_page = request.args.get('next')
            return redirect(next_page or url_for('main.dashboard'))
        flash('Invalid username or password', 'error')
    return render_template('login.html')


@auth.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out successfully', 'info')
    return redirect(url_for('auth.login'))

# Main Routes
@main.route('/')
@main.route('/dashboard')
@login_required
def dashboard():
    user_loans = BookLoan.query.filter_by(user_id=current_user.id, returned=False).all()
    overdue_loans = [loan for loan in user_loans if loan.return_date < datetime.utcnow()]
    available_books = Book.query.filter(Book.quantity > 0).limit(5).all()
    
    return render_template(
        'dashboard.html',
        loans=user_loans,
        overdue_loans=overdue_loans,
        available_books=available_books,
        now=datetime.utcnow(),
    )


@main.route('/books')
@login_required
def books():
    books = Book.query.all()
    return render_template('books.html', books=books)




@main.route('/book/<int:book_id>')
@login_required
def book_details(book_id):
    book = Book.query.get_or_404(book_id)  
    pdf_filename = f"{book_id}.pdf"
    pdf_path = os.path.join(current_app.root_path, 'pdfs', pdf_filename)

    return render_template('book_details.html', book=book, pdf_path=pdf_path)
    
  
    active_loan = BookLoan.query.filter_by(
        user_id=current_user.id, book_id=book_id, returned=False
    ).first()
    pdf_path = os.path.join(current_app.config['UPLOAD_FOLDER'], f'{book.id}.pdf')
    pdf_available = os.path.exists(pdf_path)
    
    return render_template(
        'book_details.html',
        book=book,
        has_access=active_loan is not None or current_user.is_admin,
        pdf_available=pdf_available,
    )


@main.route('/issue_book/<int:book_id>', methods=['POST'])
@login_required
def issue_book(book_id):
    book = Book.query.get_or_404(book_id)
    
    active_loans = BookLoan.query.filter_by(user_id=current_user.id, returned=False).count()
    if active_loans >= 5:
        flash('You have reached the maximum number of books allowed', 'error')
        return redirect(url_for('main.books'))
    
    overdue_loans = BookLoan.query.filter_by(
        user_id=current_user.id, returned=False
    ).filter(BookLoan.return_date < datetime.utcnow()).first()
    
    if overdue_loans:
        flash('You have overdue books. Please return them first', 'error')
        return redirect(url_for('main.books'))
    
    if book.quantity > 0:
        loan = BookLoan(
            user_id=current_user.id,
            book_id=book_id,
            issue_date=datetime.utcnow(),
            return_date=datetime.utcnow() + timedelta(days=14),
            receipt_number=f"LOAN-{uuid.uuid4().hex[:8].upper()}",
        )
        
        book.quantity -= 1
        db.session.add(loan)
        db.session.commit()
        
        flash('Book issued successfully!', 'success')
        return redirect(url_for('main.generate_receipt', loan_id=loan.id))
    
    flash('Book not available', 'error')
    return redirect(url_for('main.books'))


@main.route('/return_book/<int:loan_id>', methods=['POST'])
@login_required
def return_book(loan_id):
    loan = BookLoan.query.get_or_404(loan_id)
    
    if loan.user_id != current_user.id and not current_user.is_admin:
        abort(403)
    
    if not loan.returned:
        loan.returned = True
        loan.actual_return_date = datetime.utcnow()
        loan.book.quantity += 1
        
        if loan.return_date < datetime.utcnow():
            days_late = (datetime.utcnow() - loan.return_date).days
            loan.late_fee = days_late * 0.5
            flash(f'Late fee of £{loan.late_fee:.2f} has been applied', 'warning')
            
        db.session.commit()
        flash('Book returned successfully!', 'success')
    
    return redirect(url_for('main.dashboard'))


@main.route('/receipt/<int:loan_id>')
@login_required
def generate_receipt(loan_id):
    loan = BookLoan.query.get_or_404(loan_id)
    if loan.user_id != current_user.id and not current_user.is_admin:
        abort(403)
    return render_template('receipt.html', loan=loan)


@main.route('/api/books/<int:book_id>/pdf', methods=['GET'])
@login_required
def get_book_pdf(book_id):
    book = Book.query.get_or_404(book_id)
    pdf_path = os.path.join(current_app.config['UPLOAD_FOLDER'], f'{book.id}.pdf')
    if os.path.exists(pdf_path):
        return send_file(pdf_path, mimetype='application/pdf')
    abort(404, description="PDF not found")


@main.route('/api/books/<int:book_id>/download', methods=['GET'])
@login_required
def download_book(book_id):
    """
    Download PDF for a specific book
    """
    try:
        # Get book from database
        book = Book.query.get_or_404(book_id)
        
        # Check if user has permission to download
        if not current_user.is_authenticated:
            abort(401)
            
        # Construct PDF path
        pdf_filename = f'{book_id}.pdf'
        pdf_path = os.path.join(current_app.config['UPLOAD_FOLDER'], pdf_filename)
        
        # Check if PDF exists
        if not os.path.exists(pdf_path):
            logging.error(f"PDF not found for book ID {book_id}: {pdf_path}")
            return jsonify({
                'error': 'PDF not available for this book'
            }), 404
            
        # Log download attempt
        logging.info(f"User {current_user.id} downloading PDF for book {book_id}")
        
        # Send file with custom filename
        return send_file(
            pdf_path,
            mimetype='application/pdf',
            as_attachment=True,
            download_name=f"{secure_filename(book.title)}.pdf"
        )
        
    except Exception as e:
        logging.error(f"Error downloading PDF for book {book_id}: {str(e)}")
        return jsonify({
            'error': 'An error occurred while downloading the PDF'
        }), 500

@main.route('/api/books/<int:book_id>/upload-pdf', methods=['POST'])
@login_required
def upload_book_pdf(book_id):
    """
    Upload PDF for a specific book
    """
    try:
        # Check if the post request has the file part
        if 'pdf' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
            
        file = request.files['pdf']
        
        # If user does not select file, browser also
        # submit an empty part without filename
        if file.filename == '':
            return jsonify({'error': 'No selected file'}), 400
            
        if file and allowed_file(file.filename):
            # Secure the filename and save
            filename = f'{book_id}.pdf'
            file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
            
            # Save the file
            file.save(file_path)
            
            # Update book record if needed
            book = Book.query.get_or_404(book_id)
            book.has_pdf = True
            db.session.commit()
            
            return jsonify({
                'message': 'PDF uploaded successfully',
                'filename': filename
            }), 200
    except Exception as e:
        logging.error(f"Error uploading PDF for book {book_id}: {str(e)}")
        return jsonify({
            'error': 'An error occurred while uploading the PDF'
        }), 500

    
    
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in current_app.config['ALLOWED_EXTENSIONS']


