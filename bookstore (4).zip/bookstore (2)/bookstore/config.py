# config.py
from datetime import timedelta
import os

class Config:
        # Define base directory
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    
   
    
    UPLOAD_FOLDER = os.path.join(os.getcwd(), 'app', 'uploads')
    STATIC_FOLDER = os.path.join(os.getcwd(), 'app', 'static')
    
    # Ensure upload folder exists
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    
    # Allowed file extensions
    ALLOWED_EXTENSIONS = {'pdf'}
    SECRET_KEY = 'your-secret-key-here'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///bookstore.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    BOOK_LOAN_DURATION = timedelta(days=30)
